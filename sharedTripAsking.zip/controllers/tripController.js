const router = require('express').Router();
const { isUser } = require('../middlewares/guards');
const Trip = require('../models/Trip');
const User = require('../models/User')
const { parseError } = require('../util/parser');

router.get('/create', isUser(), async (req, res) => {
    res.render('trip/create')//here just create
})
router.post('/create', isUser(), async (req, res) => {


    try {

        const tripData = {
            startPoint: req.body.startPoint,
            endPoint: req.body.endPoint,
            date: req.body.date,
            time: req.body.time,
            carImage: req.body.carImage,
            carBrand: req.body.carBrand,
            seats: req.body.seats,
            price: req.body.price,
            description: req.body.description,
            creator: req.user._id,
            buddies: [],
            creatorEmail: req.user.email
        }

        await req.storage.createTrip(tripData, req.user._id);
        
        res.redirect('/trip/shared')
    } catch (err) {
        console.log(err.message);
        const ctx = {
            errors: parseError(err),
            tripData: {
                startPoint: req.body.startPoint,
                endPoint: req.body.endPoint,
                date: req.body.date,
                time: req.body.time,
                carImage: req.body.carImage,
                carBrand: req.body.carBrand,
                seats: req.body.seats,
                price: req.body.price,
                description: req.body.description,
                creator: req.user._id,
                buddies: [],
                creatorEmail: req.user.email
            }
        }

        res.render('trip/create', ctx)
    }
})


router.get('/details/:id', async (req, res) => {//guard nqmame tuka za6toto vseki moje da gleda details(users and guests)
    try {
        const trip = await req.storage.getTripById(req.params.id);
        
        trip.hasUser = Boolean(req.user);
        trip.isCreator = req.user && req.user._id == trip.creator;
        trip.isJoined = req.user && trip.buddies.find(x => x._id == req.user._id);//
        trip.freeSeats = Number(trip.seats) > 0;
        trip.buddies = trip.buddies.map(x=> x.email);
        trip.buddiesArray = trip.buddies.join(', ')
    
        res.render('trip/details', { trip })
    } catch (err) {
        res.redirect('/404');
    }

});

router.get('/edit/:id', isUser(), async (req, res) => {
    try {
        const trip = await req.storage.getTripById(req.params.id);
        if (trip.creator != req.user._id) {
            throw new Error('You can not edit a trip you have not created!')
        }
        res.render('trip/edit', { trip })
    } catch (err) {
        res.redirect('/trip/details/' + req.params.id)
    }
})
router.post('/edit/:id', isUser(), async (req, res) => {
    try {
        const trip = await req.storage.getTripById(req.params.id);
        if (trip.creator != req.user._id) {
            throw new Error('You can not edit a trip you have not created!')
        }

        await req.storage.editTrip(req.params.id, req.body);

        res.redirect('/trip/details/' + req.params.id)

    } catch (err) {
        const ctx = {
            errors: parseError(err),
            trip: {
                _id: req.params.id,
                startPoint: req.body.startPoint,
                endPoint: req.body.endPoint,
                date: req.body.date,
                time: req.body.time,
                carImage: req.body.carImage,
                carBrand: req.body.carBrand,
                seats: Number(req.body.seats),
                price: Number(req.body.price),
                description: req.body.description,
            }
        }
        res.render('trip/edit', ctx)
    }
})

router.get('/delete/:id', isUser(), async (req, res) => {
    try {

        const trip = await req.storage.getTripById(req.params.id);
        if (trip.creator != req.user._id) {
            throw new Error('You can not delete a trip you have not created!')
        }
        await req.storage.deleteTrip(req.params.id);
        res.redirect('/trip/shared');

    } catch (err) {
        res.redirect('/trip/details/' + req.params.id)
    }
})

router.get('/join/:id', isUser(), async(req, res)=>{
    try {
        const trip = await req.storage.getTripById(req.params.id);
        trip.email = trip.creatorEmail;
        await req.storage.joinTrip(req.params.id, req.user._id);
        res.redirect('/trip/details/' + req.params.id)
            console.log('hello================================', trip.creatorEmail);
    } catch (err) {
        console.log(err.message);
        console.log('mish');
        res.redirect('/trip/details/' + req.params.id);
    }
})

router.get('/shared', async(req, res)=>{
    const trips = await req.storage.getAllTrips();

    res.render('shared', {trips});
})


router.get('/404', async(req, res)=>{

    res.render('404');
})


router.get('/profile', async(req, res)=>{
    const tripsHistory = await req.storage.getUsersAllTrips(req.user._id);

    res.render('profile', {tripsHistory});
});


module.exports = router;
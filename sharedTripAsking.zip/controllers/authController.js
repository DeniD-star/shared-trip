//za registraziq , login i logout

const router = require('express').Router();//modulqren router
const { body, validationResult } = require('express-validator');//trqbvda da napravim validaziq tuk, za koeto 6te nie neobhodim express-validator
const { isGuest, isUser } = require('../middlewares/guards');
//body za da proverim sudurjanieto na formDatata i drugoto be6e validationResult za da ni gi izvadi kato obekt

router.get('/register', isGuest(), (req, res) => {
    res.render('register');
});

router.post(
    '/register',
    isGuest(),
    body('email', 'Invalid email!').isEmail(),
    body('password').isLength({min : 4}).withMessage('Password must be at least 4 characters long!'),//TODO according to the requirments of project
    body('rePass').custom((value, { req }) => {//Viktor kazva po= dobre tova da se pravi s if, a ne s express validator, navli4a pove4e problemi
        if (value !== req.body.password) {
            throw new Error('Passwords don\'t match!')
        }

        return true;
    }),
    // body('gender').custom((value, {req}) => {
    //     const genders = ['Male', 'Female'];
    //     if (!genders.includes(value)) {
    //       throw new Error('Gender is needed!');
    //     }
      
    //     return true;
    //   }),
    async (req, res) => {
        //testvame validaciqta
        // console.log(req.body);
        const { errors } = validationResult(req);
        try {
            if (errors.length > 0) {
                throw new Error(Object.values(errors).map(e=> e.msg).join('\n'))
            }
            //console.log(errors);
            await req.auth.register(req.body.email, req.body.password, req.body.gender);
            res.redirect('/'); //TODO change redirect location
        } catch (err) {
            console.log(err.message);
            const ctx = {
                errors: err.message.split('\n'),
                userData: {
                    email: req.body.email,
                    gender: req.body.gender
                    //paralata 6te go nakarame da si q donapi6e otnovo
                }
            }
            res.render('register', ctx);//ako hvanem gre6ki trqbva da izrendim register stranizata i da podadem edin kontext sus suob6teniq, koeto 6te bude na nivo PROECT(tuk 6te go ostavim taka, za6toto nqmame istinskiq template)
        }
    })
router.get('/login', isGuest(), (req, res) => {
    res.render('login');
})
router.post('/login', isGuest(), async (req, res) => {
    try {

        await req.auth.login(req.body.email, req.body.password);
        res.redirect('/');
    } catch (err) {
        console.log(err.message);
        let errors = [err.message];
        if(err.type == 'credential'){
            errors = ['Incorrect email or password!']
        }
        const ctx = {
            errors,
            userData: {
                email: req.body.email,
            
                //paralata 6te go nakarame da si q donapi6e otnovo
            }
        }
        res.render('login', ctx);

    }

});

router.get('/logout', (req, res) => {//samo /logout za6toto /auth idva ot routes.js, a tuk idva samo vmestnatiq
    req.auth.logout();
    res.redirect('/');
})


module.exports = router;
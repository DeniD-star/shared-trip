const {Schema, model} = require('mongoose');

const schema = new Schema({//i tuk vutre suzdavame pravilata
    startPoint : {type: String, required:[true, 'Start point is required!'], minLength: [4, 'Start point must be at least 4 characters!']}, 
    endPoint: {type: String, required:[true, 'End point is required!'], minLength: [4, 'End point must be at least 4 characters!']}, 
    date : {type: String, required:[true, 'Date is required!']}, 
    time : {type: String, required:[true, 'Time is required!']}, 
    carImage : {type: String, required:[true, 'Car image is required!'], match: [ /^http?/ , 'Image must be a valid URL!']}, 
    carBrand : {type: String, required:[true, 'Car brand is required!'], minLength: [4, 'Car brand must be at least 4 characters!']}, 
    seats : {type: Number, required:[true, 'Number of seats is required'],  min: [0, 'Minimum is 0 seats!'], max: [4 , 'Maximum is 4 seats!']}, 
    price : {type: Number, required:[true, 'Price is required'],  min: [1, 'Minimum price is 1!'], max: [50 , 'Maximum price is 50!']}, 
    description : {type: String, required :[true, 'Description is required!'], minLength: [10, 'Description must be at least 10 characters long!']}, 
    creator : [{type: Schema.Types.ObjectId, ref: 'User'}], 
    buddies : [{type: Schema.Types.ObjectId, ref: 'User', default: []}],
    creatorEmail: {type: String}
   

});

module.exports = model('Trip', schema);
//Tozi User nqma da e konkretno za zadanieto, 6te dobavim v posledstvie ne6ta koito sa  ni nujni
//kakto za sustavqneto na vseki nov model, taka i za User modela 6te nie e nujen klas Schema i funkciqta 
//--model, koito ni se predostavqt ot mongoose, t.e 
const {Schema, model} = require('mongoose');

const schema = new Schema({//i tuk vutre suzdavame pravilata

    email: {type: String, required: true},
    hashedPassword :{type: String, required: true},
    gender: { type: String,
        enum: [ "male", "female" ]
},
    tripsHistory: [{ type: Schema.Types.ObjectId, ref: 'Trip' , default: []}]

});

//sus sigurnost 6te sa neobhodimi username, edin User trabva da ima username
//sus sigurnost trqbva da ima i hashedPassword
//drugite requirements ve4e sa po uslovie na suotvetniq project

module.exports = model('User', schema);
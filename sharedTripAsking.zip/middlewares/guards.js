function isUser() {//ideqta e da izpolzvame konvenciqta koito izpolzvat vsi4ki middlewars, da se izpolzvat kato factori funkziq
    return (req, res, next) => {

        if (req.user) {
            next();
        } else {
            res.redirect('/auth/login');
        }
    }
}

function isGuest() {//s ideqta 4e mogat da se priqmat nqkakvi parametri, vutre v isGuest(parametar) and isUser(parametar)

    return (req, res, next) => {
        if (!req.user) {
            next();
        } else {
            res.redirect('/');
        }
    }
}

module.exports = {
    isUser,
    isGuest
}

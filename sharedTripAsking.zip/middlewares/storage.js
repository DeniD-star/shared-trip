const tripService = require('../services/trip');

module.exports = ()=> (req, res, next)=>{
    req.storage = {
        ...tripService
    }; 
    
    next();//tuk nqma da imame nikakvo verificirane, 6te zaka4im za req samo edin obekt storage, v koito o6te nqma ni6to, no posle slagame
}
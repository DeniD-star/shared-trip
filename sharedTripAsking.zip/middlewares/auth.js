//v tozi middleware trqbva da imame opciqta za registraziq, login i logout i
//tezi 3 funkcii trqbva da gi dobavim kato funkzionalnost v request kontexta

//imame PATERN za samiq middleware, toi trqbva da factory Function, koqto funkciq da vurne druga funkziq
//i tazi funkziq ve4e da e samoto ne6to, gunkciqta koqto priema req, res i next
//osven 3 te funkcii, vutre trqbva da verifizirame i tokena.Kogato requesta preminava prez na6iq middleware,
//authmiddlewara trqbva da vidi dali ima token, ako ima token da go validira, ako e validen da zaka4i User zapisa za kontexta
//za da mojem da go izpolzvame nadolu po actionite

//tuk 6te ni trqbva bcrypt tui kato 6te boravim s paroli
//6te ni trqbva i jwt, za da mojem da verifizirame i suzdavame tokeni

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const userService = require('../services/user');//za da mojem da namerim i suzdadem potrebitelq
const { TOKEN_SECRET, COOKIE_NAME } = require('../config/index');


module.exports = () => (req, res, next) => {
    //parse jwt
    //atached functions to context
    //sega kato zaka4ame login i register za kontexta, ozna4ava 4e tezi funkzii 6te gi dekorirame o6te 
    //toest trqbva resultata ot tqx(login i register) da go zapazim, da go vurnem kato cookie

    //i sega parseToken trqbva da go izvikame predi da sme napravili kakvoto i da e

    if (parseToken(req, res)) {
        req.auth = {
            async register(email, password, gender) {
                const token = await register(email, password, gender);
                res.cookie(COOKIE_NAME, token);
            },
            async login(email, password) {
                const token = await login(email, password);
                res.cookie(COOKIE_NAME, token);
            },
            logout() {
                res.clearCookie(COOKIE_NAME);
            }
        }

        next();
    }

}

async function register(email, password, gender) {
    //adapt parametars to project requirments
    //sledva da napravim validaciq na nivo proekt(spored negovite iziskvaniq)

    const existEmail = await userService.getUserByEmail(email);

    if (existEmail) {
        throw new Error('Email is taken!')
    } 
    //v protiven slu4ai trqbva da go susdadem, kato purvo trqbva da mu kriptirame parolata i sled tova ot userservisa 6te izvikame createUser, podavaiki parolata, koqto sme suzdali

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await userService.createUser(email, hashedPassword, gender);

    //sled kato sme go suzdali, trqbva da lognem usera

    //TODO log in user
    return generateToken(user);//tuk pak ni trqbva funkciqta za generirane na tokena, poneje pri registraziq 
    //potrebitelq e avtomati4no lognat

}

async function login(email, password) {
    const user = await userService.getUserByEmail(email);

    if (!user) {
        const err = new Error ('No such user!');
        err.type = 'credential';
        throw err;//tova e spesific error, koito e za survera, actionite hva6tat tazi gre6ka i q vru6tat na klienta v generic gre6ka
    }

    //ako imame takuv user, sravnqvame parolata koqto toi e vkaral s criptirana mu ve4e parola

    const hasMatch = await bcrypt.compare(password, user.hashedPassword);

    if (!hasMatch) {
        const err = new Error ('Incorrect password!');
        err.type = 'credential';
        throw err;
    }

    //ako imame mach, trqbva da generirame token i da go vurnem kato cookie na potrebitelq, i sled tova da zaka4im potrebitelq za sesiqta,
    //samo 4e zaka4aneto na potrebitelq za sesiqta se okazva 4e ne nujno da go pravim, za6toto sled login actiona 6te redirektne kum nqkoq druga stranica
    //koeto ozna4ava 4e browsera na potrebitelq 6te zaredi nova stranica, izpra6taiki nova zaqvka, v koqto 6te e vlu4en tokena koito toku6to sme generirali
    //taka 4e trqbva samo da generirame tokena i da mu go izpratim
    //pravim go v druga funcziq koqto q suzdavame po-dolu generateToken



    //i toq token sled kato sme go napravili, 6te go izpratim kato cookie
    //i za da go izpratim kato cookie, ni e nujen requesta\

    return generateToken(user);
}

//trqbva ni f=q za verificaziq na tokena

function generateToken(userData) {
    return jwt.sign({// podavame mu obekta, koito iskame da podpi6em
        _id: userData._id,
        email: userData.email,
         gender: Boolean(userData.gender)//username tozi koito e vuvel otna4alo pri registraciqta si ,zapasen v basata danni

    }, TOKEN_SECRET);//podavame go kato parametar
}

function parseToken(req, res) {
    const token = req.cookies[COOKIE_NAME];
    //vadim tokena
    if (token) {
        try {
            const userData = jwt.verify(token, TOKEN_SECRET);//iskame da go verifizirame
            req.user = userData;//zaka4ame obekta na userdatata za req.user
            res.locals.user = userData;
        } catch (err) {
            res.clearCookie(COOKIE_NAME);//ako verificaziqta nemine, turkame, redirektvame i vru6tame false
            res.redirect('/auth/login');
            return false;
        }
    }
    return true;

}
//za kofigurirane na routovete s appa

const authController = require('../controllers/authController');
const tripController = require('../controllers/tripController');
const homeController = require('../controllers/homeController');

module.exports = (app) => {
    app.use('/auth', authController);
    app.use('/trip', tripController);
    app.use('/', homeController) //kazvame mu na koi put (/auth) da mauntne routera(authController)
   
}

//ozna4ava kato doide zaqvka s auth, maha6 auth ot putq i ostanaliq put go izpra6ta6 na authControllera,
//authControllera 6te vidi suotvetno kakvo ima sled auth(login ili register, 6te vidi i metoda i 6t'e izpi6e suotvetnoto ne6to)'
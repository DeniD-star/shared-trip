
const mongoose = require('mongoose');//v database ni trqbva mongoose za da svurjem na6eto prilojenie s data base
const { DB_CONNECTION_STRING } = require('./index'); //vzimame si connectionstringa za mogooseconnection 

module.exports = (app) => {//vupreki 4e app=a tuk nqma da ni trqbva , no go slagame, neznaem dali nqma da ni potrqbva v bude6te
    //pi6em nujnite opzii
    return new Promise((resolve, reject) => {
        mongoose.connect(DB_CONNECTION_STRING, {
            useNewUrlParser: true,
            useUnifiedTopology: true
            //i tuk ima edno createIndex, no v projectProduction ne e dobra practica da se slaga
            //otnasq se za indexa, ako imame iziskvane ne6to da e unique, ako iskame index 6te go nastroim ru4no
        })

        const db = mongoose.connection;//tova raboti asyncronno, poneje vruzkata s bazata e asyncronna, oba4e bihme iskali v edna realno situaciq puk i tuk s configuraziqta da produljim i startiraneto na prilojenieto,4ak kogato basata e gotova i za taq cel vru6tame edin Promise
        db.on('error', (err) => {
            console.error('connection error:', err)
            reject(err)
        });
        db.once('open', function () {
            //we are connected
            console.log('Database ready!');
            resolve();
        })

    })

}
const hbs = require('express-handlebars');
const express = require('express');//paterna tuk e 4e express 6te prieme app- a i 6te mu pribavi nqkoi ne6ta
const cookieParser = require('cookie-parser');//su6to i cookie-parser

const authMiddleware = require('../middlewares/auth');//zaka4ame middleware
const storageMiddleware = require('../middlewares/storage');//zaka4ame middleware

module.exports = (app)=>{
    app.engine('hbs', hbs.engine({
        extname: 'hbs'//tuka nie izpisvame raz6irenieto da hbs, ina4e e handlebars i e mnogo dulgo za pisane vseki put, zatova imame vuzmojnost da pod4artaem
    }))//registrirame nov engine v express

    app.set('view engine', 'hbs');//tuk configurirame defaultnoto raz6irenie, koeto express 6te dobavi kato mu kajem response(res.render), po princip bi trqbvalo da podadem file, no za po=udobno mojem da skipnem raz6irenieto, no ne e ne6to zaduljitelno da se pravi, moje i bez nego
    app.use('/static', express.static('static'));//tuk konfigurirame stati4nite failove da se vzimat ot papkata statik v na6eto prilojenie
    app.use( express.urlencoded({extended: true}));//pozvolqva da parsvame vsi4kite ni body koito idvat ot formulqri
    app.use(cookieParser());
    app.use(authMiddleware())
    //tuk trqbva da dobavim storage i authmiddleware

    app.use((req, res, next)=>{
        if(!req.url.includes('favicon')){
            console.log('>>>', req.method, req.url);

            if(req.user){
                console.log('Known user', req.user.email);
            }
    
          
        }
        next();
    })

    app.use(storageMiddleware());
}


//tozi file NODE.JS go namira avtomati4no v config

module.exports = {
    PORT: 3000,
    DB_CONNECTION_STRING : 'mongodb://localhost:27017/sharedTrip',
    TOKEN_SECRET : 'this is very secure11',
    COOKIE_NAME : 'SESSION_TOKEN'
}
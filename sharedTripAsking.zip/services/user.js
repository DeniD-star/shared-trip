//userservice trqbva da moje da suzdava potrebitel-funkziq 1
//trqbva da moje da otkriva potrebitel po potrebitelsko ime(username)-funkziq 2
//da otkriva potrebitel po email(ako go imame po zadanie, tova e konkretno po proekta)

//tezi dve funkzii 6te sa async, tui kato 6te pravim ne6to v bazata danni, kogato rabotim s basata danni, imame asyncronnost
//za da rabotq tezi dve funkzii ni e neobhodim modela User ot papka models

const User = require('../models/User');

async function createUser(email, hashedPassword, gender) {
    //adapt properties to project requirements
    //tuk priemame 4e survisa raboti s validni danni,tuk nqma da pravim validaciq, priemame 4e tq e stanala nqkude po-nagore(v middleware ili v kontroller, nqma zna4enie)
    //parolata tuk trqbva da e hi6irana, predi hi6iraneto go pravihme vutre v tazi funkziq, oba4e posle tova go napravihme na nivo middleware, za6toto tam izvur6vahme drugi operacii(decryptirane na tokena, otkrivaneto na usera, verifiziraneto na parolata pri login)
    //taka 4e 6te promenim parolata da hashPassword, i rolqta na tozi service 6te bude edinstveno da suzdade istanziq na modela i da q save-ne
    //o4akvame 4e toq koito zaredi servisa, toi vsu6nost 6te svur6i rabotata, i v na6iq slu4ai tova 6te e middlewara

    //suzdavame usera
    const user = new User({
        email,
        hashedPassword,
        gender,
        tripsHistory: []
    })

    await user.save()//savame go
    return user; // iskame da go vurnem tui kato e mnogo veroqtno middleware ili actiona, koito vika tova deistvie createUser da iska da napravi ne6to s metadannite, naprimer 6te iska da vzeme _id, ako iskame v posledstvie toq potrebitel da lognem direktno
    //(sled uspe6na registraziq, redirektvame kum homePage i potrebitelq trqbva ve4e da e lognat, zatova returnvame user)
}



async function getUserByEmail(email) {//tazi funcziq 6te q poslzvame kato registrirame potrebitel, dali imame registriran potrebitel
    //tq moje da ne vurne ni6to, ako nqmame potrebitel
    //adapt properties to project requirements
    const patern = new RegExp(`^${email}$`, 'i');//pravim si patern za regexa, kato trqbva da slojiv ^ za string start i $ za string end
    const user = await User.findOne({ email: { $regex: patern } });//regexa 6te tursi po poleto username, operatora e $regex, regexa 6te vklu4va username kato stoinost(koeto moje da e kato regex ili samo string)
    return user;
}

//add functions for finding user by other properties, as specified in project requirments(primerno tursene po email)

module.exports = {
    createUser,
    getUserByEmail
}
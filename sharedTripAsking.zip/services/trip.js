const Trip = require('../models/Trip');
//kogato pravq shema model za Play ili Trip, trqbva da ima creator kato edno ot poletata
const  User = require('../models/User');
//const userService = require('../services/user')

async function getAllTrips() {
    return Trip.find({}).lean();
}

async function getUsersAllTrips(userId) {
    const user = await User.findById(userId).populate('tripsHistory').lean();
    //const user = await User.findOne({}).lean();
    console.log(user.tripsHistory + 'ssssssssssssss');
    return user.tripsHistory;
}
async function getTripById(id) {
    const trip = await Trip.findById(id).populate('buddies').lean();
    return trip;
}
async function createTrip(tripData, userId) {
    const trip = new Trip(tripData);
    const user = await User.findById(userId);
    console.log(user.email + 'deeeeee');
   trip.creatorEmail = user.email;

   //console.log(trip.creatorEmail , 'bbvjbdskvnjek')
    user.tripsHistory.push(trip);
    return Promise.all([user.save(), trip.save()]);

}
async function editTrip(id, tripData) {
    const trip = await Trip.findById(id);

    trip.startPoint = tripData.startPoint;
    trip.endPoint = tripData.endPoint;
    trip.date = tripData.date;
    trip.time = tripData.time;
    trip.carImage = tripData.carImage;
    trip.carBrand = tripData.carBrand;
    trip.seats = Number(tripData.seats);
    trip.price = Number(tripData.price);
    trip.description = tripData.description;

    return trip.save();
}


async function joinTrip(tripId, userId) {
    const trip = await Trip.findById(tripId);
    const user = await User.findById(userId);
    


   

    if (user._id == trip.creator) {
        throw new Error('Cannot join trip you have created!')
    }
    //user.tripsHistory.push(trip);

    trip.buddies.push(user);
    trip.creatorEmail= user.email;

    trip.seats--;
    //console.log(trip.buddies)

    return Promise.all([user.save(), trip.save()]);

}

async function deleteTrip(id) {
    return Trip.findByIdAndDelete(id);
}

module.exports = {
    getAllTrips,
    getUsersAllTrips,
    getTripById,
    createTrip,
    editTrip,
    deleteTrip,
    joinTrip
}
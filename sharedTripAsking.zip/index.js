//index.js , tuk zapo4vame i startirvame na6eto prilojenie-app, za koeto ni trqbva express biblioteka
//i configuraziq s vsi4ki files koito se namirat v papka CONFIG
//---PORT-v index.js; --DATABASECONFIG - v database.js; --EXPRESSCONFIG- v express.js

const express = require('express');
const { PORT } = require('./config/index');
const databaseConfig = require('./config/database');
const expressConfig = require('./config/express');
const routesConfig = require('./config/routes');//zarejdame routera(pravim routConfiguration s appa)
//const userService = require('./services/user');//za testvaneto
//const authMiddleware = require('./middlewares/auth');// za testvaneto

start();
async function start() {
    const app = express();
    await databaseConfig(app);//sega tova e asyncronno i za da mojem da go awaitnem 6te napravim f-qta start
    expressConfig(app);
    routesConfig(app);

    app.get('/', (req, res) => {
        res.send('It works!');
    })

    app.listen(PORT, () => {
        // testAuth();
        console.log(`Apllication started at http://localhost:${PORT}`)
    });
}

//Za testvane
// async function testAuth() {
//     try {

//         const reqMock = {};//nujen ni e req, podavame prosto edin prazen obekt i ni6to drugo nepravim, 6te imame resMock, i nextMOck, za da mojem da izvikame tazi funciq koqto se exportva
//         const resMock = {
//             cookie() {
//                 console.log('Set cookie', arguments);//o4akvame da bude viknato tova, i da vidim argumentite idva6ti ot funkciqta register v auth.js
//             }
//         }

//         const nextMock = () => { };
//         // const result = await userService.createUser('Peter', '123123'); //tova e za suzdavaneto na user
//         // console.log(result);
//         // const user = await userService.getUserByUsername('peter');//iziskvaneto e da moje da getva usera, dori da e s malka bukva
//         // console.log(user);
//         const auth = authMiddleware();
//         auth(reqMock, resMock, nextMock)
//         await reqMock.auth.login('Veli', '123sd');//resultata ot tova e 4e trqbva da se izvika resMocka
//         //o4akvame v basata danni da se poqvi nov potrebitel
//     } catch (err) {
//         console.log('Error', err.message);
//     }
// }